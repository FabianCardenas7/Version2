@extends('layout')

@section('content')

<article>
    <h1>Codigo Barras</h1> <p> {{ $producto["CodigoBarras"] }} </p>
    <h1>Nombre</h1> <p> {{ $producto["Nombre"] }} </p>
    <h1>Precio</h1> <p> {{ $producto["Precio"] }} </p>
    <h1>Cantidad</h1> <p> {{ $producto["Cantidad"] }} </p>
    <h1>Caducidad</h1> <p> {{ $producto["Caducidad"] }} </p>
    <h1>Lote</h1> <p> {{ $producto["Lote"] }} </p>
</article>

@endsection