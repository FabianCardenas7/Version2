@extends('layout')

@section('content')
<form action='{{ route("productos.update", $producto->Id) }}' method='POST'>
    @csrf
    {{ method_field('PUT') }}
    <input value='{{$producto["CodigoBarras"]}}' type='text' name='CodigoBarras' placeholder='Codigo de barras'/>
    
    <input value='{{$producto["Nombre"]}}' type='text' name='Nombre' placeholder='Nombre'/>
    
    <label for='Precio'>Precio</label>
    <input value='{{$producto["Precio"]}}' type='number' name='Precio' min='0' step='0.01' placeholder='20'/>
    
    <label for='Cantidad'>Cantidad</label>
    <input value='{{$producto["Cantidad"]}}' type='number' name='Cantidad' min='1' step='1' placeholder='1'/>
    
    <label for='Cantidad'>Fecha de caducidad</label>
    <input value='{{$producto["Caducidad"]}}' type='date' name='Caducidad'/>
    
    <input value='{{$producto["Lote"]}}' type='text' name='Lote' placeholder='Lote'/>

    <input type='submit' value='Guardar'/>
</form>
@endsection