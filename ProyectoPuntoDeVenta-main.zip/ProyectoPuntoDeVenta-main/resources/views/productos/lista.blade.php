@extends('layout')

@section('content')
    <a href='{{ route("productos.create") }}' role='button'> Crear </a>
    <table>
        
        <tr> 
            <th> Codigo de barras </th>
            <th> Nombre </th>
            <th> Precio </th>
            <th> Cantidad </th>
            <th> Caducidad </th>
            <th> Lote </th>
            <th> Acciones </th>
        </tr>

    @foreach($productos as $producto)
        <tr> 
            <td>
                {{ $producto['CodigoBarras'] }}                
            </td>

            <td>
                {{ $producto['Nombre'] }}                
            </td>
            <td>
                {{ $producto['Precio'] }}                                
            </td>
            <td>
                {{ $producto['Cantidad'] }}                
            </td>
            <td>
                {{ $producto['Caducidad'] }}                                
            </td>
            <td>
                {{ $producto['Lote'] }}                                
            </td>
            <td>
                <a role='button' href='{{ route("productos.show", $producto["Id"]) }}'>Ver</a>
                <a role='button' href='{{ route("productos.edit", $producto["Id"]) }}'>Editar</a>
                <form action='{{ route("productos.destroy", $producto["Id"]) }}' method='POST'>
                    @csrf
                    {{ method_field('DELETE') }}
                    <input type='submit' value='Eliminar'/>                
                </form>
            </td>
        </tr>
    @endforeach
    </table>
@endsection