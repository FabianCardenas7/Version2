@extends('layout')

@section('content')
<form action='/productos' method='POST'>
    @csrf
    @method('POST')
    <input type='text' name='CodigoBarras' placeholder='Codigo de barras'/>
    <input type='text' name='Nombre' placeholder='Nombre'/>
    <label for='Precio'>Precio</label>
    <input type='number' name='Precio' min='0' step='0.01' placeholder='20'/>
    <label for='Cantidad'>Cantidad</label>
    <input type='number' name='Cantidad' min='1' step='1' placeholder='1'/>
    <label for='Cantidad'>Fecha de caducidad</label>
    <input type='date' name='Caducidad'/>
    <input type='text' name='Lote' placeholder='Lote'/>

    <input type='submit' value='Enviar'/>
</form>
@endsection